import React from "react";
import styles from "./InfoBox.module.scss";
export class InfoBox extends React.Component {
  render() {
    const name = "Ilya";
    const slides = [
      {
        title: "Time to Share: 6 for $3.99*",
        img:
          "https://res.cloudinary.com/dx4wkpab8/image/upload/v1573640170/comp_plate_promo1_wsmolg.png",
        description:
          "Lorem ipsum dolor sit amet. consectetur adipisicing elit, sed do eiusmod tempor incididunt ut la bore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exefcitalion ullamoo laboris nisi ut aliquip ex ea commodo oonsequat.",
        note:
          "* At vero eos et accusamus et iusto odo dtgntsslmos duclmus qui blandltlis praesentlum voluptatum delenrtl atque corruptl quos doQres et quas molestlas exceptun sint occaecatl cupidrtate non pro v dent, slmllique sunt In culpa qui otflcia deserunt mollrtia anlmi. id est la bo aim et dolorum tuga.",
        productUrl:
          "https://res.cloudinary.com/dx4wkpab8/image/upload/v1573640170/comp_plate_promo1_wsmolg.png"
      },
      {
        title: "Rise 'n shine",
        img:
          "https://res.cloudinary.com/dx4wkpab8/image/upload/v1573640171/comp_plate_promo2_nlqjfe.png",
        description:
          "Lorem ipsum dolor sit amet. consectetur adipisicing elit, sed do eiusmod tempor incididunt ut la bore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exefcitalion ullamoo laboris nisi ut aliquip ex ea commodo oonsequat.",
        note:
          "* At vero eos et accusamus et iusto odo dtgntsslmos duclmus qui blandltlis praesentlum voluptatum delenrtl atque corruptl quos doQres et quas molestlas exceptun sint occaecatl cupidrtate non pro v dent, slmllique sunt In culpa qui otflcia deserunt mollrtia anlmi. id est la bo aim et dolorum tuga.",
        productUrl:
          "https://res.cloudinary.com/dx4wkpab8/image/upload/v1573640171/comp_plate_promo2_nlqjfe.png"
      }
    ];

    return (
      <div className={styles.infoBox}>
        <div className={styles.slides}>
          <div className={styles.slide}>
            <img
              className={styles.slide}
              src="https://res.cloudinary.com/dx4wkpab8/image/upload/v1573640170/comp_plate_promo1_wsmolg.png"
              alt=""
            />
            <h2>{"Time to Share: 6 for $3.99*"}</h2>
            <p>
              Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse
              repellendus voluptatem odit minima iste ut reprehenderit
              perspiciatis repudiandae totam, voluptatibus dolor, cupiditate
              earum, ipsam error non expedita quis vero iure.
            </p>
          </div>
        </div>
        <div className={styles.controls}>
          <button className={styles.control}>{"<<<"}</button>
          <button className={styles.control}>{"<"}</button>
          <button className={styles.control}>{">"}</button>
          <button className={styles.control}>{">>>"}</button>
        </div>
      </div>
    );
  }
}
