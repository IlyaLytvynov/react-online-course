import React from 'react';

export class TestComp extends React.Component {
  render() {
    return (
      <p>
        Lorem ipsum, dolor sit amet consectetur adipisicing elit. Minima impedit
        amet illum libero. Inventore quos veritatis, ipsum minima vel quae iure
        aperiam quaerat reprehenderit quod ut quas aspernatur. Natus,
        laboriosam?
      </p>
    );
  }
}
